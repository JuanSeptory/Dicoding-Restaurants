import 'regenerator-runtime'; /* for async await transpile */
import '../styles/main.css';

// console.log('Hello Coders! :)');

import dataRestorant from '../DATA.json';

//Untuk tombol menu
const hamburger = document.querySelector('.hamburger');
const navMenu = document.querySelector('.nav-menu');
const main = document.querySelector('main');
const jumbotron = document.querySelector('.jumbotron');

hamburger.addEventListener('click', () => {
  hamburger.classList.toggle('active');
  navMenu.classList.toggle('active');
});

document.querySelectorAll('.nav-link').forEach((n) =>
  n.addEventListener('click', () => {
    hamburger.classList.remove('active');
    navMenu.classList.remove('active');
  })
);

main.addEventListener('click', (event) => {
  hamburger.classList.remove('active');
  navMenu.classList.remove('active');
  event.stopPropagation();
});

jumbotron.addEventListener('click', (event) => {
  hamburger.classList.remove('active');
  navMenu.classList.remove('active');
  event.stopPropagation();
});

const listPost = document.querySelector('.card');
let listRest = '';

dataRestorant.restaurants.forEach((dataRest) => {
  listRest += `
  <article tabindex="0" id="card" class="card-item">
  <h2 class="card-item-title">${dataRest.city}</h2>
  <img src=${dataRest.pictureId} width="450" alt="${dataRest.name}" />
  <div class="card-item-description">
    <h4>Rating: ${dataRest.rating}</h4>
    <h3>${dataRest.name}</h3>
    <p>${dataRest.description}</p>
  </div>
</article>
  `;
  listPost.innerHTML = listRest;
});
